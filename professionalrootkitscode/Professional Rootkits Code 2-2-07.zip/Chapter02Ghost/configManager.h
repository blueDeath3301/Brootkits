// Copyright Ric Vieler, 2006
// Support header for ConfigManager.c

#ifndef _CONFIG_MANAGER_H_
#define _CONFIG_MANAGER_H_

char	masterPort[10];
char	masterAddress1[4];
char	masterAddress2[4];
char	masterAddress3[4];
char	masterAddress4[4];

NTSTATUS Configure();


#endif
